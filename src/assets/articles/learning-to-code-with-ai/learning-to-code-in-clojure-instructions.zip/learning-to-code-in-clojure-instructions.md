# Event Inventory - Clojure Web Application

## Project Overview

**Event Inventory** is a web application for managing and tracking events and their associated inventory. Built in Clojure with test-driven development (TDD) as the core methodology. The application will be containerized for self-hosting with Cloudflare Tunnel support.

**Developer Status**: New to Clojure. Teaching through practice and working code.

---

## Core Principles

### Test-Driven Development (TDD)
- **Always write tests first** before implementation
- Red → Green → Refactor cycle for every feature
- Unit tests for business logic, integration tests for APIs
- No code lands without corresponding tests
- Keep tests simple, focused, and isolated

### Learning Through Building
- Explain Clojure concepts when introducing them (immutability, persistent data structures, functional paradigms)
- Show idiomatic Clojure patterns, not just "it works"
- Point out where Clojure differs from imperative languages (state management, concurrency, etc.)
- Provide clear examples of why Clojure's approach matters

---

## Technology Stack

### Core Framework
- **Clojure** (latest stable, typically 1.11.x)
- **Ring** - HTTP server abstraction
- **Reitit** - Modern, fast HTTP router with data-driven design
- **Compojure** - Alternative/supplement for routing (optional, but common)

### Database
- **SQLite** (development, simple setup)
- **HugSQL** or **Duct** database layer (simple SQL-based approach)
- **Migrations**: `migratus` for schema versioning

### Testing
- **clojure.test** - Built-in testing framework (primary)
- **Midje** - Alternative for BDD-style testing (optional)
- **Test Fixtures** for database state management

### Build & Dependencies
- **Leiningen** (or **deps.edn** with CLI tools)
- Start with Leiningen for simplicity

### Containerization
- **Docker** - Multi-stage build for minimal image
- **docker-compose** optional for local development with services
- Environment-based configuration for self-hosting

---

## Project Structure

```
event-inventory/
├── src/
│   └── event_inventory/
│       ├── core.clj              # App entry point, server setup
│       ├── handler.clj           # HTTP request handlers
│       ├── routes.clj            # Route definitions (Reitit)
│       ├── db/
│       │   ├── core.clj          # Database connection, queries
│       │   └── migrations/       # SQL migration files
│       └── models/
│           ├── event.clj         # Event domain logic
│           └── inventory.clj     # Inventory domain logic
├── test/
│   └── event_inventory/
│       ├── core_test.clj         # Integration tests
│       ├── handler_test.clj      # HTTP handler tests
│       ├── db/
│       │   └── core_test.clj     # Database tests
│       └── models/
│           ├── event_test.clj    # Event logic tests
│           └── inventory_test.clj
├── resources/
│   ├── config.edn               # Configuration file
│   └── db/
│       └── migrations/          # SQL migration files
├── Dockerfile
├── docker-compose.yml (optional)
├── project.clj                  # Leiningen config
├── .env.example                 # Environment variables template
└── README.md
```

---

## Development Workflow

### 1. Starting a Feature
1. **Write a test first** (test file before implementation)
2. Run tests → they fail (RED)
3. Write minimal code to pass tests (GREEN)
4. Refactor for clarity and performance (REFACTOR)
5. Commit when tests pass

### 2. Testing Strategy

**Unit Tests** (clojure.test)
- Test pure functions (domain logic)
- One assertion per test when possible
- Mock external dependencies
- Use `testing` blocks to organize related tests

**Integration Tests**
- Test HTTP routes with actual handler
- Use test database fixtures
- Verify end-to-end flows
- Test error responses and edge cases

**Database Tests**
- Wrap in transactions that rollback after each test
- Use fixtures to seed test data
- Test queries in isolation
- Verify migration success

### 3. Running Tests Locally
```bash
lein test                    # Run all tests
lein test event-inventory.handler-test  # Run specific test file
lein test :only my.namespace/specific-test  # Run specific test
```

### 4. REPL Workflow
The REPL is your development partner in Clojure:
```bash
lein repl
```
- Load the running application
- Test functions interactively
- Reload changed code with `(user/reset)` or `(refresh)`
- Quick feedback loop

---

## Common Clojure Concepts to Know

### Immutability
- Data structures are immutable by default
- Operations return new collections; originals unchanged
- Safer concurrency with no locks needed

### Persistent Data Structures
- Maps, vectors, lists: efficient structural sharing
- Updates are O(log n), not O(n)

### Functional Programming
- Functions are first-class values
- `map`, `filter`, `reduce` are your friends
- Avoid loops; use `doseq` or `loop` when necessary

### Keywords and Symbols
- Keywords (`:key`) are identifiers, often used as map keys
- Symbols (`my-var`) are variable/function names

### Protocols & Records
- Protocols define a set of related functions
- Records are like structs with built-in protocol support
- Use for domain models (Events, Inventory items)

### Error Handling
- Prefer `try-catch` for exceptions
- Use `:error` keys in response maps for API errors
- Validate inputs early in handler functions

---

## API Design Principles

### RESTful Endpoints (Reitit)
All endpoints should return JSON. Follow REST conventions:

```
POST   /api/events              - Create event
GET    /api/events              - List events
GET    /api/events/{id}         - Get event by ID
PUT    /api/events/{id}         - Update event
DELETE /api/events/{id}         - Delete event

POST   /api/events/{id}/inventory     - Add inventory item
GET    /api/events/{id}/inventory     - List inventory for event
PUT    /api/events/{id}/inventory/{id} - Update inventory item
```

### Response Format
All JSON responses should follow a consistent structure:
```json
{
  "status": "success|error",
  "data": {},
  "error": "error message if status=error"
}
```

### Error Responses
- Use appropriate HTTP status codes (400, 404, 500, etc.)
- Include error details in response body
- Log errors server-side
- Never expose stack traces to clients

---

## Setup & First Steps

### Prerequisites
1. Java JDK 11+
2. Leiningen (install from https://leiningen.org/)
3. Docker (for containerization)

### Initial Setup
```bash
# Create new project from template (if not already done)
lein new app event-inventory
cd event-inventory

# Add dependencies to project.clj:
# - ring, ring-jetty-adapter
# - reitit, ring
# - next.jdbc (database access)
# - migratus (migrations)
# - clojure.test (built-in)

# Install dependencies
lein deps

# Run REPL
lein repl

# Run tests
lein test
```

### Database Setup
1. Create `resources/db/migrations/001-init.up.sql` with schema
2. Create matching `.down.sql` for rollback
3. Use `migratus` CLI to run migrations
4. Test fixtures should handle migrations for tests

---

## Docker & Deployment

### Dockerfile Strategy
- **Multi-stage build**: Smaller final image
- Stage 1: Build with Leiningen, create uberjar
- Stage 2: Minimal runtime image with Java
- Expose port 3000 (or configured port)

### Environment Configuration
Store in `.env` file (not in git):
```
DATABASE_URL=sqlite:///db/events.db
PORT=3000
ENV=development
```

### Running Locally
```bash
docker build -t event-inventory .
docker run -p 3000:3000 event-inventory
```

### Self-Hosting Considerations
- Use Cloudflare Tunnel for secure external access
- Store sensitive config in environment variables
- Use SQLite or managed database service
- Implement basic auth if needed
- Log important operations

---

## Code Quality Standards

### Naming Conventions
- `kebab-case` for functions and variables (not snake_case)
- `PascalCase` for protocols and records
- Prefix private helpers with `-` (e.g., `-internal-helper`)
- Namespace your functions: `event-inventory.models.event/create`

### Code Style
- Keep functions small and focused
- One responsibility per function
- Use `let` to break complex expressions into steps
- Comments explain "why," not "what" (code shows what)
- Aim for 80-character line limit where practical

### Documentation
- Docstrings for all public functions
- Example usage in docstrings when helpful
- README with setup and usage instructions
- Code comments for non-obvious logic

---

## Testing Checklist for Each Feature

Before marking a feature complete:
- [ ] Unit tests written first, implementation follows
- [ ] All tests pass (`lein test`)
- [ ] Edge cases tested (empty inputs, invalid IDs, etc.)
- [ ] Error cases tested (what happens when things fail?)
- [ ] Database transactions tested (for persistence features)
- [ ] API endpoints return correct HTTP status codes
- [ ] Response format is consistent with spec
- [ ] No console warnings or errors during test run

---

## Debugging Tips

### Using the REPL
```clojure
; Load your code
(require '[event-inventory.models.event :as event])

; Test a function
(event/create {:name "Test Event"})

; Inspect data
(clojure.pprint/pprint result)

; Reload on code change
(user/reset)
```

### Logging
- Use `println` for debugging (gets to stdout)
- Consider `clojure.tools.logging` for production
- Log request/response in middleware

### Testing Tips
- Use `is` for assertions: `(is (= expected actual))`
- Use `testing` to group related tests
- Use `with-redefs` to mock functions in tests
- Use database fixtures to reset state between tests

---

## Common Gotchas (Clojure-Specific)

1. **Lazy Evaluation**: `map` returns a lazy sequence; sometimes you need `into []` or `doall`
2. **Truthiness**: Only `false` and `nil` are falsy; `0`, `""`, `[]` are truthy
3. **Keyword vs String**: `:name` and `"name"` are different; be consistent
4. **Mutation**: Don't try to mutate; use `atom` or `ref` if you need mutable state (rarely)
5. **Thread Safety**: Use `mapv` instead of `map` if order matters; prefer immutable approach

---

## Resources

- **Official Docs**: https://clojure.org/
- **Clojure by Example**: https://kimh.github.io/clojure-by-example/
- **Ring Documentation**: https://github.com/ring-clojure/ring
- **Reitit Router**: https://metosin.github.io/reitit/
- **Building Web Applications**: https://www.braveclojure.com/
- **4Clojure**: Practice problems for learning

---

## Getting Help in Claude Code

When asking for help:
1. Mention "TDD first" if you want tests written before implementation
2. Point out if you're stuck on a Clojure concept
3. Reference which file or function is causing issues
4. Ask for explanations of unfamiliar patterns
5. Request refactoring suggestions for clarity

Remember: Every line of code should have a corresponding test that passes.

---

## Feature Checklist Template

Use this when starting a new feature:

```
Feature: [Feature Name]
[ ] Design data model/schema
[ ] Write test cases for new behavior
[ ] Write integration tests for API endpoints
[ ] Implement business logic (models)
[ ] Implement HTTP handlers
[ ] Implement database layer
[ ] Update database schema if needed
[ ] All tests passing
[ ] Code review for style and clarity
[ ] Documentation updated
```
